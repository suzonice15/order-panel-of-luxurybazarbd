
@extends('admin.master')
@section('main',"Cache")
@section('active',"Cache ")
@section('main-content')
<section class="content">
    <div class="container-fluid">
        <div class="card card-defualt">
            <h2 style="padding: 17px;color: green;">Cache Remove Successfully</h2>          
        </div>
    </div>
</section>  
  

    @endsection